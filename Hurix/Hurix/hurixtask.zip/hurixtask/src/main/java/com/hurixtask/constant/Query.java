package com.hurixtask.constant;

public class Query {

	public static final String insertLanguage = "insert into hurix.user (name,address) values(?,?)";

	


}
